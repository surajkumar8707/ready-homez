@extends('layouts.app')
@section('title', getSettings()->app_name.':: Blog Page')
@section('content')
@endsection
