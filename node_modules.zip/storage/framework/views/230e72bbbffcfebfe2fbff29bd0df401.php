<?php $__env->startSection('content'); ?>
    <div class="back_re">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title">
                        <h2>Our Room</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- our_room -->
    <div class="our_room">
        <div class="container">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <h2><?php echo e($room->name); ?></h2>
                        <div class="room_img">
                            <figure>
                                <img src="<?php echo e(public_asset($room->photo)); ?>" alt="<?php echo e($room->name); ?>" />
                            </figure>
                        </div>
                        <p class="room_price">₹<?php echo e(number_format($room->price, 2)); ?></p>
                        <p><?php echo e($room->description); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end our_room -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\guest-house\resources\views/rooms_details.blade.php ENDPATH**/ ?>