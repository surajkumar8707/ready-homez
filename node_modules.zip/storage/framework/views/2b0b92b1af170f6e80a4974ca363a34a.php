<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content -->
    <div class="container-fluid flex-grow-1 container-p-y">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">All Bookings</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">

                        <?php if($bookings->isEmpty()): ?>
                            <p>No bookings found.</p>
                        <?php else: ?>
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Room</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>City</th>
                                        <th>Arrival</th>
                                        <th>Departure</th>
                                        <th>Booked At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($booking->room->name ?? 'N/A'); ?></td> <!-- Room relationship -->
                                            <td><?php echo e($booking->name); ?></td>
                                            <td><?php echo e($booking->email); ?></td>
                                            <td><?php echo e($booking->phone); ?></td>
                                            <td><?php echo e($booking->city); ?></td>
                                            <td><?php echo e(date('d M, Y', strtotime($booking->arrival))); ?></td>
                                            <td><?php echo e(date('d M, Y', strtotime($booking->departure))); ?></td>
                                            <td><?php echo e(date('d M, Y H:i', strtotime($booking->created_at))); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- / Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\guest-house\resources\views/admin/bookings/index.blade.php ENDPATH**/ ?>