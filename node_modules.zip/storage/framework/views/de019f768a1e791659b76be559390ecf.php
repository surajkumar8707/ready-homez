<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<?php if(Session::has('success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('success')); ?>", 'Success!')
    </script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('error')); ?>", 'error!')
    </script>
<?php endif; ?>

<?php if(Session::has('info')): ?>
    <script>
        toastr.info("<?php echo e(Session::get('info')); ?>", 'info!')
    </script>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
    <script>
        toastr.warning("<?php echo e(Session::get('warning')); ?>", 'warning!')
    </script>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\panel\resources\views/admin/layout/toastr.blade.php ENDPATH**/ ?>