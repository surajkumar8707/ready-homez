<footer>
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class=" col-md-4">
                    <h3>About US</h3>
                    <p style="text-align: justify;">
                        At Guest House, we pride ourselves on offering exceptional hospitality and comfort in a serene and welcoming environment. Located in the heart of Uttrakhand, our hotel combines luxury with a home-like atmosphere to provide an unforgettable stay for both business and leisure travelers.
                    </p>

                </div>
                <div class="col-md-4">
                    <h3>Menu Link</h3>
                    <ul class="link_menu">
                        <li class="<?php echo e(isActiveRoute('front.home')); ?>">
                            <a href="<?php echo e(route('front.home')); ?>">Home</a>
                        </li>
                        <li class="<?php echo e(isActiveRoute('front.about')); ?>">
                            <a href="<?php echo e(route('front.about')); ?>">About</a>
                        </li>
                        <li class="<?php echo e(isActiveRoute('front.room')); ?>">
                            <a href="<?php echo e(route('front.room')); ?>">Our room</a>
                        </li>
                        <li class="<?php echo e(isActiveRoute('front.gallery')); ?>">
                            <a href="<?php echo e(route('front.gallery')); ?>">Gallery</a>
                        </li>
                        <li class="<?php echo e(isActiveRoute('front.contact')); ?>">
                            <a href="<?php echo e(route('front.contact')); ?>">Contact Us</a>
                        </li>
                        <li class="<?php echo e(isActiveRoute('front.terms.condition')); ?>">
                            <a href="<?php echo e(route('front.terms.condition')); ?>">Terms and Condition</a>
                        </li>
                        <li class="<?php echo e(isActiveRoute('front.privacy.policy')); ?>">
                            <a href="<?php echo e(route('front.privacy.policy')); ?>">Privacy Policy</a>
                        </li>
                    </ul>
                </div>
                <div class=" col-md-4">
                    <h3>Contact US</h3>
                    <ul class="conta">
                        <li><i class="fa fa-map-marker" aria-hidden="true"></i> <?php echo e($settings->address); ?></li>
                        <li><i class="fa fa-mobile" aria-hidden="true"></i> <a href="tel:<?php echo e($settings->contact); ?>">
                                <?php echo e($settings->contact); ?> </a></li>
                        <li> <i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:<?php echo e($settings->email); ?>"> <?php echo e($settings->email); ?> </a></li>
                        <li>
                            <ul class="social_icon">
                                <?php if($social->facebook_show == 1): ?>
                                    <li><a href="<?php echo e($social->facebook); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php if($social->twitter_show == 1): ?>
                                    <li><a href="<?php echo e($social->twitter); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php if($social->linkedin_show == 1): ?>
                                    <li><a href="<?php echo e($social->linkedin); ?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                    </li>
                                <?php endif; ?>
                                <?php if($social->youTube_show == 1): ?>
                                    <li><a href="<?php echo e($social->youTube); ?>"><i class="fa fa-youtube-play"
                                                aria-hidden="true"></i></a></li>
                                <?php endif; ?>
                            </ul>
                        </li>

                    </ul>
                </div>
            </div>
        </div>
        <div class="copyright">
            <div class="container">
                <div class="row">
                    <div class="col-md-10 offset-md-1">

                        <p>
                            &copy; <?php echo e(date('Y')); ?> All Rights Reserved.
                            
                        </p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>


<script>
    toastr.options = {
        closeButton: true,
        debug: true,
        newestOnTop: true,
        progressBar: true,
        positionClass: "toast-top-right",
        preventDuplicates: true,
        onclick: null,
        timeOut: 10000, // Time in milliseconds (5 seconds)
        extendedTimeOut: 5000, // Time in milliseconds for extended timeout (1 second)
    };
</script>

<?php if(session('success')): ?>
    <script>
        toastr.success("<?php echo session('success'); ?>", "Success !");
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        toastr.error("<?php echo session('error'); ?>", "Error !");
    </script>
<?php endif; ?>

<?php if(session('info')): ?>
    <script>
        toastr.info("<?php echo session('info'); ?>", "Info !");
    </script>
<?php endif; ?>

<?php if(session('warning')): ?>
    <script>
        toastr.warning("<?php echo session('warning'); ?>", "Warning !");
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\guest-house\resources\views/layouts/footer.blade.php ENDPATH**/ ?>