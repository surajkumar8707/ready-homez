<?php $__env->startSection('title', getSettings()->app_name.':: Rooms Page'); ?>
<?php $__env->startSection('content'); ?>
    <div class="back_re">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="title">
                        <h2>Our Room</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!-- our_room -->
        <div class="our_room">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="titlepage">
                            <h2>Our Room</h2>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 col-sm-12">
                            <a href="<?php echo e(route('front.room.detail.page', $room->id)); ?>">
                                <div id="serv_hover" class="room">
                                    <div class="room_img">
                                        <figure><img src="<?php echo e(public_asset($room->photo)); ?>" alt="<?php echo e($room->name); ?>" /></figure>
                                    </div>
                                    <div class="bed_room">
                                        <h3><?php echo e($room->name); ?></h3>
                                        <p class="room_price">₹<?php echo e(number_format($room->price, 2)); ?></p> <!-- Display the price -->
                                        <p><?php echo e($room->description); ?></p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12">
                            <p>No rooms available at the moment.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- end our_room -->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\guest-house\resources\views/room.blade.php ENDPATH**/ ?>